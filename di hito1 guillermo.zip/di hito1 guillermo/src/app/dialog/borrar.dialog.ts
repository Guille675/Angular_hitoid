import { Component } from '@angular/core';


@Component({
    selector: "borrar-dialog",
    templateUrl: "./borrar-dialog.html"
})

export class BorrarDialog {}