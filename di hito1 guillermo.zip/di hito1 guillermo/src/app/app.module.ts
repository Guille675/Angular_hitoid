import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import {
  MatAutocompleteModule,
  MatButtonModule,
  MatCheckboxModule,
  MatTableModule,
  MatToolbarModule,
  MatSidenavModule,
  MatFormFieldModule,
  MatSelectModule,
  MatInputModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatCardModule,
  MatListModule,
  MatPaginatorModule,
  MatSortModule,
  MatSnackBarModule,
  MatDialogModule,
  MatGridListModule,
  MatRadioModule
} from '@angular/material';

import { FlexLayoutModule } from '@angular/flex-layout';

import { AppComponent } from './app.component';
import {ClienteComponent, ClienteFormDialog, ClienteForm } from './cliente/cliente.component';
import { AppRoutingModule } from './app-routing.module';
import { ClienteDetailComponent } from './cliente-detail/cliente-detail.component';
import { ProductosComponent } from './productos/productos.component';

import { ProductosDialog} from './dialog/productos.dialog';
import { BorrarDialog } from './dialog/borrar.dialog';

import { ProductosDetailComponent } from './productos-detail/productos-detail.component';

import { TotalGeneral } from './totales/total-general';


import { VentasForm } from './forms/ventas.form'
import { ProductosForm } from './forms/productos.form'
import { DetalleVentaForm } from './forms/detalle-venta.form'





@NgModule({
  declarations: [
    AppComponent,
    ClienteComponent,
    ClienteDetailComponent,
    ProductosComponent,
    
    ProductosDetailComponent,
  
    BorrarDialog,
    ProductosDialog,
    ClienteFormDialog, 
    ClienteForm,
    TotalGeneral,
    VentasForm,
    ProductosForm,
    DetalleVentaForm,

    
  ],
  entryComponents: [BorrarDialog, ProductosDialog, ClienteFormDialog],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatAutocompleteModule,
    MatToolbarModule,
    MatButtonModule,
    MatCheckboxModule,
    MatTableModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCardModule,
    MatListModule,
    MatPaginatorModule,
    MatSortModule,
    MatSnackBarModule,
    MatDialogModule,
    FlexLayoutModule,
    MatGridListModule,
      MatRadioModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
