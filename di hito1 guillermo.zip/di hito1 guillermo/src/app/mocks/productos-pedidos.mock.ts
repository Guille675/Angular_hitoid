import { ProductosPedidos } from './../modelo/ProductosPedidos';


export const ProductosPedidosMock: ProductosPedidos[] = [
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    {
        'id': 1,
       'productoId': 1,
       'nombreProducto': 'Prueba Nombre',
        'precio': 100,
        'iva': 5,
        'cantidad': 12,
        'subTotalIva': 100,
        'subTotal': 100
    },
    

] 