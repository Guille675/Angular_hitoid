
export class Cliente  {
    id: number;
    nombre: string;
    apellido: string;
    ruc: string;
    telefono: string;
    direccion1: string; 
    direccion2: string;
    tipo: Tipo;
    activo: boolean;
    fechaNacimiento: string;
    createdOn: string;
    constructor(){
        this.tipo = new Tipo();
    }
}

export class Tipo {
    id: number;
    nombre: string;
    createdOn: string;
}

export class Direccion {
    direccion1: string; 
    direccion2: string;
}