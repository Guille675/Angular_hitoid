
 export class Producto {
    id: number;
    nombre: string;
    codigo: string;
    descripcion: string;
    notas:string;
    url: string;
    activo:boolean;
    precioCompra: number;
    porcenGan: number;
    precioVenta: number;
    porcenIva: number;
    porcenDesc: number=0;
    stockInicial:number   = 0.0;
    stockMinimo :number   = 0.0;
    stockPreOrden:number  = 0.0;
    totalIngreso:number   = 0.0;
    totalSalida:number    = 0.0;
    totalStock:number     = 0.0;
    estadoStock:string     = "Normal";

 }