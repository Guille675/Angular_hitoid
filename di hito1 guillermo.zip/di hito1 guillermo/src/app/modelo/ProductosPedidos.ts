export class ProductosPedidos {
    id: number;
    productoId: number;
    nombreProducto: string;
    precio: number;
    iva: number;
    cantidad: number;
    subTotalIva: number;
    subTotal: number;
}